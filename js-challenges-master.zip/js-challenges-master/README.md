# js-challenges
Javascript challenges for WIT
