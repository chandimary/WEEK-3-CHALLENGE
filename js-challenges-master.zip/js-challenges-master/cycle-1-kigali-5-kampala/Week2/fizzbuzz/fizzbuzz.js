function fizzBuzz(list1, list2) {
    // Your code here
}

module.exports = fizzBuzz;