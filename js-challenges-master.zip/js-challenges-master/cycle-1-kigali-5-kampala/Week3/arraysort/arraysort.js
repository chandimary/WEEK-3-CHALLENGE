function arraySort(anArray) {
    // Your code here
}


module.exports = arraySort;