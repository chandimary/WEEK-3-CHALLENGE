class BankAccount {
    constructor() {
        // your code here
    }

    getBalance() {
        // your code here
    }

    open() {
        // your code here
    }

    deposit() {
        // your code here
    }

    withdraw() {
        // your code here
    }

    close(){

    }
}